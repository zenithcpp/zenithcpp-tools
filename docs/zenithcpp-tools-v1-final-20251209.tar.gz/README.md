
Header-only, pure-ISO-C++23 constexpr utilities.

- `constexpr_string_view.hpp` — full `std::string_view` in constexpr - `constexpr_vector.hpp` — real dynamic array in constexpr

No dependencies. No macros. No runtime cost.

```cpp constexpr auto v = zenith::constexpr_vector{}; v.push_back(42); static_assert(v[0] == 42); 

<<'EOF' 
